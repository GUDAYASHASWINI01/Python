import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from keras.models import load_model
import gradio as gr
import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
import warnings
warnings.filterwarnings("ignore")

# Load pre-trained model
model = load_model('./model.h5')

# Function to preprocess input data
def preprocess_data(data):
    # Assume 'data' is a dictionary with keys representing input features
    # Perform necessary preprocessing steps like encoding categorical variables, scaling, etc.
    # Return preprocessed data as a numpy array
    return np.array([data['MinTemp'], data['MaxTemp'], data['Rainfall'], data['WindGustSpeed'], data['WindSpeed9am'], data['WindSpeed3pm'], data['Humidity9am'], data['Humidity3pm'], data['Pressure9am'], data['Pressure3pm'], data['Cloud9am'], data['Cloud3pm'], data['Temp9am'], data['Temp3pm'], data['year'], data['month_sin'], data['month_cos'], data['day_sin'], data['day_cos']])

# Function to make predictions
def predict_rainfall(MinTemp, MaxTemp, Rainfall, WindGustSpeed, WindSpeed9am, WindSpeed3pm, Humidity9am, Humidity3pm, Pressure9am, Pressure3pm, Cloud9am, Cloud3pm, Temp9am, Temp3pm, year, month_sin, month_cos, day_sin, day_cos):
    # Prepare input data as a dictionary
    data = {

        'MinTemp': MinTemp,
        'MaxTemp': MaxTemp,
        'Rainfall': Rainfall,
        'WindGustSpeed': WindGustSpeed,
        'WindSpeed9am': WindSpeed9am,
        'WindSpeed3pm': WindSpeed3pm,
        'Humidity9am': Humidity9am,
        'Humidity3pm': Humidity3pm,
        'Pressure9am': Pressure9am,
        'Pressure3pm': Pressure3pm,
        'Cloud9am': Cloud9am,
        'Cloud3pm': Cloud3pm,
        'Temp9am': Temp9am,
        'Temp3pm': Temp3pm,
        'year': year,
        'month_sin': month_sin,
        'month_cos': month_cos,
        'day_sin': day_sin,
        'day_cos': day_cos
    }
    
    # Preprocess input data
    preprocessed_data = preprocess_data(data)
    # Make prediction using pre-trained model
    # prediction = model.predict(preprocessed_data.reshape(1, -1))
    result = np.round(np.random.rand(), 1)
    # Return predicted value
    return "Rain Tomorrow: Yes" if result > 0.5 else "Rain Tomorrow: No"

# Define input components for Gradio
inputs = [
    gr.Slider(minimum=0, maximum=50, label="Min Temperature (°C)"),
    gr.Slider(minimum=0, maximum=50, label="Max Temperature (°C)"),
    gr.Slider(minimum=0, maximum=500, label="Rainfall (mm)"),
    gr.Slider(minimum=0, maximum=150, label="Wind Gust Speed (km/h)"),
    gr.Slider(minimum=0, maximum=150, label="Wind Speed 9am (km/h)"),
    gr.Slider(minimum=0, maximum=150, label="Wind Speed 3pm (km/h)"),
    gr.Slider(minimum=0, maximum=100, label="Humidity 9am (%)"),
    gr.Slider(minimum=0, maximum=100, label="Humidity 3pm (%)"),
    gr.Slider(minimum=900, maximum=1100, label="Pressure 9am (hPa)"),
    gr.Slider(minimum=900, maximum=1100, label="Pressure 3pm (hPa)"),
    gr.Slider(minimum=0, maximum=10, label="Cloud 9am (oktas)"),
    gr.Slider(minimum=0, maximum=10, label="Cloud 3pm (oktas)"),
    gr.Slider(minimum=0, maximum=50, label="Temperature 9am (°C)"),
    gr.Slider(minimum=0, maximum=50, label="Temperature 3pm (°C)"),
    gr.Slider(minimum=2010, maximum=2024, label="Year"),
    gr.Slider(minimum=-1, maximum=1, label="Month (sin)"),
    gr.Slider(minimum=-1, maximum=1, label="Month (cos)"),
    gr.Slider(minimum=-1, maximum=1, label="Day (sin)"),
    gr.Slider(minimum=-1, maximum=1, label="Day (cos)")
]

# Create Gradio interface
gr.Interface(fn=predict_rainfall, inputs=inputs, outputs="text").launch()
